package teladepedidos;

import cadastro.Cadastro;
import ferramentas.Ler;
import ferramentas.Pedido;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 *
 * @author carva
 */
public class FXMLTelaDePedidosController implements Initializable {
    
    @FXML private Label lblValor;
    @FXML private Label lblDesconto;
    @FXML private Label lblEntrega;
    @FXML private Label lblTAP;
    @FXML private Label lblPizzas;
    @FXML private Button btPedido;
    @FXML private Button btCadastro;
    @FXML private Button btAdd;
    @FXML private Button btReset;
    @FXML private MenuButton mnPizzas;
    @FXML private MenuItem miPdq;
    @FXML private MenuItem miPdf;
    @FXML private MenuItem miPdch;
    @FXML private MenuItem miPdtq;
    @FXML private MenuItem miPdca;
    @FXML private MenuItem miGu;
    @FXML private MenuItem miCC;
    @FXML private TextField tfNome;
    @FXML private TextField tfPizza;
    @FXML private TextField tfAcompanhamento;
    @FXML private TextField tfDesconto;
    @FXML private TextField tfEntrega;
    
    Ler l = new Ler();
    Cadastro c = new Cadastro();
    Pedido p1 = new Pedido();
    Pedido p2 = new Pedido();
    Pedido p3 = new Pedido();
    Pedido p4 = new Pedido();
    Pedido p5 = new Pedido();
    Pedido p6 = new Pedido();
    Pedido pc = new Pedido();
    float va = 0;
    float tap1;
    float tap2;
    float tap3;
    float tap4;
    
     @FXML private void Cadastrando(ActionEvent event) {
        c.mostrar();
    }
    
     @FXML private void Descontando(ActionEvent ae) {
        lblDesconto.setText(tfDesconto.getText());
        p1.setDesconto(Integer.parseInt(tfDesconto.getText()));
        p2.setDesconto(Integer.parseInt(tfDesconto.getText()));
        p3.setDesconto(Integer.parseInt(tfDesconto.getText()));
        p4.setDesconto(Integer.parseInt(tfDesconto.getText()));
        p5.setDesconto(Integer.parseInt(tfDesconto.getText()));
        p6.setDesconto(Integer.parseInt(tfDesconto.getText()));
        tap1 = va;
        tap2 = Float.parseFloat(lblDesconto.getText());
        tap3 = Float.parseFloat(lblEntrega.getText());
        tap4 = (tap1-tap2)+tap3;
        lblTAP.setText(Float.toString(tap4));
        
    }
    
     @FXML private void Anotando(ActionEvent event) {
        String leitura = l.leituraSimples();
        if(tfNome.getText()!=""&&tfPizza.getText()!=""&&leitura.contains(tfNome.getText())){
            l.ler("clientes\\"+tfNome.getText()+".txt", tfNome, lblPizzas, lblValor, lblDesconto, lblEntrega,lblTAP);
        }
        else{
            System.out.println("ERROR");
        }
    }
     
     @FXML private void Adicionando(ActionEvent event) {
         
       if(pc.getPdq()==true){
           p1.setQuantidade(p1.getQuantidade()+1);
           if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de queijo");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de queijo");
           }
           
           va = va+p1.getValor();
           lblValor.setText(Float.toString(va));
       }
       else if(pc.getPdc()==true){
           p2.setQuantidade(p2.getQuantidade()+1);
           if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de calabresa");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de calabresa");
           }
           va = va+p2.getValor();
           lblValor.setText(Float.toString(va));
       }
       else if(pc.getPdf()==true){
           p3.setQuantidade(p3.getQuantidade()+1);
           if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de frango");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de frango");
           }
           va = va+p3.getValor();
           lblValor.setText(Float.toString(va));
       }
       else if(pc.getPdch()==true){
           p4.setQuantidade(p4.getQuantidade()+1);
           if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de charque");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de charque");
           }
           va = va+p4.getValor();
           lblValor.setText(Float.toString(va));
       }
       else if(pc.getPdtq()==true){
           p5.setQuantidade(p5.getQuantidade()+1);
           if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de três queijos");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de três queijos");
           }
           va = va+p5.getValor();
           lblValor.setText(Float.toString(va));
       }
       else if(pc.getPdca()==true){
           p6.setQuantidade(p6.getQuantidade()+1);
           if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de carne");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Pizza de queijo");
           }
           va = va+p6.getValor();
           lblValor.setText(Float.toString(va));
           
       }
          tap1 = va;
          tap2 = Float.parseFloat(lblDesconto.getText());
          tap3 = Float.parseFloat(lblEntrega.getText());
          tap4 = (tap1-tap2)+tap3;
          lblTAP.setText(Float.toString(tap4));
           
         
    }
     
     @FXML private void Entregando(ActionEvent ae) {
        lblEntrega.setText(tfEntrega.getText());
        tap1 = va;
        tap2 = Float.parseFloat(lblDesconto.getText());
        tap3 = Float.parseFloat(lblEntrega.getText());
        tap4 = (tap1-tap2)+tap3;
        lblTAP.setText(Float.toString(tap4));
    }
      
     @FXML private void Resetando(ActionEvent event) {
        p1.resetarQuantidade();
        p2.resetarQuantidade();
        p3.resetarQuantidade();
        p4.resetarQuantidade();
        p5.resetarQuantidade();
        p6.resetarQuantidade();
        lblPizzas.setText("");
        lblValor.setText("");
        lblDesconto.setText("");
        lblEntrega.setText("");
        tfNome.setText("");
        tfPizza.setText("");
        tfDesconto.setText("");
        tfEntrega.setText("");
        tfAcompanhamento.setText("");
        pc.setAcQuantidade1(0);
        pc.setAcQuantidade2(0);
        pc.setAcompanhamento("");
    }
     
     @FXML private void pdqPress(ActionEvent event) {
        tfPizza.setText(p1.getPizza());
        pc.anotar(0);
      
    }
     
     @FXML private void pdcPress(ActionEvent event) {
        tfPizza.setText(p2.getPizza());
        pc.anotar(1);
 
    }
     
     @FXML private void pdfPress(ActionEvent event) {
        tfPizza.setText(p3.getPizza());
        pc.anotar(2);

    }
     
     @FXML private void pdchPress(ActionEvent event) {
        tfPizza.setText(p4.getPizza());
        pc.anotar(3);

    }
     
     @FXML private void pdtqPress(ActionEvent event) {
        tfPizza.setText(p5.getPizza());
        pc.anotar(4);

    }
     
     @FXML private void pdcaPress(ActionEvent event) {
        tfPizza.setText(p6.getPizza());
        pc.anotar(5);

    }
    
     @FXML private void ac1(ActionEvent event) {
         pc.setAcompanhamento("Guarana");
         tfAcompanhamento.setText(pc.getAcompanhamento());
         pc.setAcQuantidade1(pc.getAcQuantidade1()+1);
         float vc = Float.parseFloat(lblValor.getText());
         vc = vc+3.5f;
         lblValor.setText(Float.toString(vc));
         if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Guarana");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Guarana");
           }
          tap1 = vc;
          tap2 = Float.parseFloat(lblDesconto.getText());
          tap3 = Float.parseFloat(lblEntrega.getText());
          tap4 = (tap1-tap2)+tap3;
          lblTAP.setText(Float.toString(tap4));
    }
     
     @FXML private void ac2(ActionEvent event) {
         pc.setAcompanhamento("Coca cola");
         tfAcompanhamento.setText(pc.getAcompanhamento());
         pc.setAcQuantidade2(pc.getAcQuantidade1()+2);
         float vc = Float.parseFloat(lblValor.getText());
         vc = vc+5.5f;
         lblValor.setText(Float.toString(vc));
         if(lblPizzas.getText()==""){
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Coca cola");
           }
           else{
               lblPizzas.setText(lblPizzas.getText()+"\n(1x)Coca cola");
           }
          tap1 = vc;
          tap2 = Float.parseFloat(lblDesconto.getText());
          tap3 = Float.parseFloat(lblEntrega.getText());
          tap4 = (tap1-tap2)+tap3;
          lblTAP.setText(Float.toString(tap4));
    }
     
     
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     p1.pedir("Pizza de queijo", 19.00f,2.00f);
     p2.pedir("Pizza de calabresa",20.00f, 2.00f);
     p3.pedir("Pizza de frango",20.00f, 2.00f);
     p4.pedir("Pizza de charque",20.00f, 2.00f);
     p5.pedir("Pizza de três queijos",25.00f, 2.00f);
     p6.pedir("Pizza de carne", 20.00f,2.00f);
     
    }    

    
    
}
