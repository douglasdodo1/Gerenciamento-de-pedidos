package teladepedidos;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author carva
 */
public class TelaDePedidos extends Application {
    
    private static Stage stage;
    
    @Override
    public void start(Stage stage) throws Exception {
        
        Parent root = FXMLLoader.load(getClass().getResource("FXMLTelaDePedidos.fxml"));

        Scene scene = new Scene(root);
        stage.setTitle("Pedidos");
        stage.setScene(scene);
        stage.show();
        setStage(stage);
    }
    public static void main(String[] args) {
        launch(args);
    }

    public static Stage getStage() {
        return stage;
    }

    public static void setStage(Stage stage) {
        TelaDePedidos.stage = stage;
    }
    
}
