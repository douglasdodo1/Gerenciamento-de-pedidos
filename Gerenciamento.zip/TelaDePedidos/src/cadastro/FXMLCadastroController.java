package cadastro;

import ferramentas.Arquivo;
import ferramentas.Escrever;
import ferramentas.Ler;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author carva
 */
public class FXMLCadastroController implements Initializable {
    
    
    
    
    
    
    @FXML
    private Button btCadastro;
    @FXML
    private TextField txfNome;
    @FXML
    private TextField txfBairro;
    @FXML
    private TextField txfRua;
    @FXML
    private TextField txfComplemento;
    @FXML
    private TextField txfNumero;
    @FXML
    private TextField txfTelefone;
    
    Arquivo aq = new Arquivo();
    Escrever e = new Escrever();
    String nome = "";
    Ler l = new Ler();

    
    @FXML
    private void Concluido(ActionEvent event) {
        nome = txfNome.getText();
        aq.criarArquivo(nome);
         e.escrever("clientes\\Nomes.txt",nome);
         e.escrever("clientes\\"+nome+".txt",nome+",");
         e.escrever("clientes\\"+nome+".txt",txfBairro.getText()+",");
         e.escrever("clientes\\"+nome+".txt",txfRua.getText()+",");
         e.escrever("clientes\\"+nome+".txt",txfComplemento.getText()+",");
         e.escrever("clientes\\"+nome+".txt",txfNumero.getText()+",");
         e.escrever("clientes\\"+nome+".txt",txfTelefone.getText()+",");
         //l.ler("clientes\\"+nome+".txt");
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
