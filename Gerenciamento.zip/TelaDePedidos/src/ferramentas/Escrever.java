package ferramentas;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author carva
 */
public class Escrever {
    
    public static void escrever(String caminho, String texto){
        try(BufferedWriter br = new BufferedWriter(new FileWriter(caminho,true))){
            PrintWriter esc = new PrintWriter(br);
            esc.print(texto);
            esc.close();
        }
        
        catch(IOException e){
            System.out.println("ERRO: "+e.getMessage());
        }
        
    }
}

