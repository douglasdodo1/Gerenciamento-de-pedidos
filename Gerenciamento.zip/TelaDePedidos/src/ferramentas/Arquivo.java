package ferramentas;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author carva
 */
public class Arquivo {
    public void criarArquivo(String nome ){
    File arq = new File("Clientes\\"+nome+".txt");
        try {
            arq.createNewFile();
        } catch (IOException ex) {
            System.out.println("ERRO: "+ex.getMessage());
        }
    }
}
