package ferramentas;

/**
 *
 * @author carva
 */
public class Pedido {
    private String pizza;
    private float valor;
    private float desconto;
    private float entrega = 3.00f;
    private float tap;
    private String acompanhamento;
    private int acQuantidade1;
    private int acQuantidade2;
    private Boolean Pdq = false;
    private Boolean Pdc = false;
    private Boolean Pdf = false;
    private Boolean Pdch = false;
    private Boolean Pdtq = false;
    private Boolean Pdca = false;
    private int quantidade = 0;
    
    public void resetarQuantidade(){
        this.setQuantidade(0);
    }
    
    public void pedir(String p,float v,float d){
        this.setPizza(p);
        this.setValor(v);
        this.setDesconto(d);
        this.setTap((this.getValor()-this.getDesconto())+this.getEntrega());
    }
    
    public void informacoes(){
        System.out.println("Pizza: "+this.getPizza());
        System.out.println("Desconto: "+this.getDesconto());
        System.out.println("Entrega: "+this.getEntrega());
        System.out.println("Total a pagar: "+this.getTap());
    }
    
    public void anotar(int n){
        switch(n){
          case 0:
              this.setPdq(true);
              this.setPdc(false);
              this.setPdf(false);
              this.setPdch(false);
              this.setPdtq(false);
              this.setPdca(false);
          break;
          case 1:
              this.setPdq(false);
              this.setPdc(true);
              this.setPdf(false);
              this.setPdch(false);
              this.setPdtq(false);
              this.setPdca(false);
          break;
          case 2:
              this.setPdq(false);
              this.setPdc(false);
              this.setPdf(true);
              this.setPdch(false);
              this.setPdtq(false);
              this.setPdca(false);
          break;
          case 3:
              this.setPdq(false);
              this.setPdc(false);
              this.setPdf(false);
              this.setPdch(true);
              this.setPdtq(false);
              this.setPdca(false);
          break;
          case 4:
              this.setPdq(false);
              this.setPdc(false);
              this.setPdf(false);
              this.setPdch(false);
              this.setPdtq(true);
              this.setPdca(false);
          break;
          case 5:
              this.setPdq(false);
              this.setPdc(false);
              this.setPdf(false);
              this.setPdch(false);
              this.setPdtq(false);
              this.setPdca(true);
          break;
       }   
    }

    public String getPizza() {
        return pizza;
    }

    public void setPizza(String pizza) {
        this.pizza = pizza;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public float getDesconto() {
        return desconto;
    }

    public void setDesconto(float desconto) {
        this.desconto = desconto;
    }

    public float getEntrega() {
        return entrega;
    }

    public void setEntrega(float entrega) {
        this.entrega = entrega;
    }

    public float getTap() {
        return tap;
    }

    public void setTap(float tap) {
        this.tap = tap;
    }

    public Boolean getPdq() {
        return Pdq;
    }

    public void setPdq(Boolean Pdq) {
        this.Pdq = Pdq;
    }

    public Boolean getPdc() {
        return Pdc;
    }

    public void setPdc(Boolean Pdc) {
        this.Pdc = Pdc;
    }

    public Boolean getPdf() {
        return Pdf;
    }

    public void setPdf(Boolean Pdf) {
        this.Pdf = Pdf;
    }

    public Boolean getPdch() {
        return Pdch;
    }

    public void setPdch(Boolean Pdch) {
        this.Pdch = Pdch;
    }

    public Boolean getPdtq() {
        return Pdtq;
    }

    public void setPdtq(Boolean Pdtq) {
        this.Pdtq = Pdtq;
    }

    public Boolean getPdca() {
        return Pdca;
    }

    public void setPdca(Boolean Pdca) {
        this.Pdca = Pdca;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getAcompanhamento() {
        return acompanhamento;
    }

    public void setAcompanhamento(String acompanhamento) {
        this.acompanhamento = acompanhamento;
    }

    public int getAcQuantidade1() {
        return acQuantidade1;
    }

    public void setAcQuantidade1(int acQuantidade1) {
        this.acQuantidade1 = acQuantidade1;
    }

    public int getAcQuantidade2() {
        return acQuantidade2;
    }

    public void setAcQuantidade2(int acQuantidade2) {
        this.acQuantidade2 = acQuantidade2;
    }

}
