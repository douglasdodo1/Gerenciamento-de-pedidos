package ferramentas;

/**
 *
 * @author carva
 */
public class Cliente {
    private String nome;
    private String bairro;
    private String rua;
    private String complemento;
    private int numero;
    private String telefone;

    public  void informacoes(){
        System.out.println("Informações sobre o cliente:");
        System.out.println("");
        System.out.println("Nome: "+this.getNome());
        System.out.println("Bairro: "+this.getBairro());
        System.out.println("Rua: "+this.getRua());
        System.out.println("Complemento: "+this.getComplemento());
        System.out.println("Numero: "+this.getNumero());
        System.out.println("Telefone: "+this.getTelefone());
    }

    public Cliente(String nome, String bairro, String rua, String complemento, int numero, String telefone) {
        this.nome = nome;
        this.bairro = bairro;
        this.rua = rua;
        this.complemento = complemento;
        this.numero = numero;
        this.telefone = telefone;
    }

    

    

   

    

   

   


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
}
