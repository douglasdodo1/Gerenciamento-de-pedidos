package ferramentas;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author carva
 */
public class Ler {
   public void ler(String caminho,TextField tfNome,Label lblPizzas,Label lblValor,Label lblDesconto,Label lblEntrega,Label lblTAP){

		List<Cliente> list = new ArrayList<Cliente>();
		Alert nota = new Alert(Alert.AlertType.INFORMATION);
                
                
		try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
			
			String line = br.readLine();
			//line = br.readLine();
			while (line != null) {
				
				String[] vect = line.split(",");
				String nome = vect[0];
				String bairro = vect[1];
                                String rua = vect[2];
				String complemento = vect[3];
                                int numero = Integer.parseInt(vect[4]);
                                String telefone = vect[5];
				
				Cliente prod = new Cliente(nome, bairro,rua ,complemento,numero,telefone);
				list.add(prod);
				line = br.readLine();
                                nota.setTitle("Pedido de "+tfNome.getText());
                                nota.setHeaderText("Pedido de "+tfNome.getText());
                                nota.setContentText("Pedido:"+lblPizzas.getText()+"\nValor: "+lblValor.getText()
                                 +"\nDesconto: "+lblDesconto.getText()+"\nEntrega: "+lblEntrega.getText()
                                 +"\nTotal a pagar: "+lblTAP.getText()+"\n-----------------------------------------------"
                                 +"\nInformações do cliente:"
                                 +"\nBairro: "+bairro+"\nRua: "+rua+"\nComplemento: "+complemento+"\nNúmero: "
                                 +Integer.toString(numero)+"\nTelefone: "+telefone);
                                 nota.showAndWait();
			}	
                        
			
			for (Cliente p : list) {
			   p.informacoes();
			}
		}
		catch (IOException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

   public String leituraSimples(){
       String conteudo = "";
      try{
          FileReader arq = new FileReader("clientes\\Nomes.txt");
          BufferedReader lerArq = new BufferedReader(arq);
          String linha = "";
          try{
              linha = lerArq.readLine();
              while(linha!=null){
                  conteudo +=linha;
                  linha = lerArq.readLine();
              }
          }
          catch(IOException ex){
              System.out.println("erro");
          }
      } 
      catch(FileNotFoundException ex){
          System.out.println("nao encontrado");
      }
      
       if (conteudo.contains("erro")) {
           return "";
       } else {
           return conteudo;
       }
   }   
}
   

   

